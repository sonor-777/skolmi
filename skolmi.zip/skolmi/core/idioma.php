<?php
/*
 if( $_GET )       
        $key = ( isset($_GET['idioma']) )? $_GET['idioma'] : $_SESSION['idiomadefecto'] ;  
    else
        $key = $_SESSION['idiomadefecto'] ;  */
        
        $db= new conexion();
	$queryconfiguracion=$db->query("SELECT * FROM configuracion");
	$configuracion=$db->recorrer($queryconfiguracion);

	$idiomaInicial=$configuracion['conLenguajePredeterminado'];
	$multilenguaje=$configuracion['conMultilenguaje'];
	$_SESSION['multilenguaje']=$multilenguaje;

// Primero averiguamos el idioma seleccionado.

if(isset($_GET['idioma'])=="es")
		$idioma=isset($_GET['idioma'])? $_GET['idioma']:$_SESSION['idioma'];
	else
        $idioma=isset($_POST['idioma'])? $_POST['idioma']:$_SESSION['idioma'];

if (isset($idioma) && $idioma!=''){
	$idioma=strtolower($idioma);
}
else {
	$idioma=$idiomaInicial;
	}

$_SESSION['idioma']=$idioma;

// Cargamos el fichero de idioma. Por defecto español.
include_once "core/lenguaje/".$_SESSION['idioma']."_idioma.php";

?>