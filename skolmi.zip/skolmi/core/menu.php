<?php
/*
 if( $_GET )       
        $key = ( isset($_GET['idioma']) )? $_GET['idioma'] : $_SESSION['idiomadefecto'] ;  
    else
	    $key = $_SESSION['idiomadefecto'] ;  */

// Primero averiguamos el idioma seleccionado.
$idioma=isset($_POST['idioma'])? $_POST['idioma']:$_SESSION['idioma'];
if (isset($idioma) && $idioma!='' )
   $idioma=strtolower($idioma);
else
   $idioma='es';

$_SESSION['idioma']=$idioma;
// Cargamos el fichero de idioma. Por defecto español.
include_once "core/lenguaje/".$_SESSION['idioma']."_idioma.php";

?>