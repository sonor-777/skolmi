<?php
/* NUCLEO DE LA APLICACION */

/* CONSTANTE*/
define('BASE_URL', 'http://localhost/consol365/');
define('LOGO_LOGIN','<img src="html/dist/img/logo.png">');
define('LOGO','<img height="46px" src="html/dist/img/logo.png">');

// urls
// ICON
$icn = "<link rel='icon' href='html/images/icon.png'>";
define('APP_ICON', $icn);



?>