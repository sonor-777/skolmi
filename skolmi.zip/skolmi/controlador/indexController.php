<?php 
session_start();

					//include('assignAlert.php');
					
					  //include ('./modelo/iwant/legendarios/model.DatosPersonales.php'); 
					  //$valor= new iWant();	
					  //$numeroderegistro=$valor->colsultaRegistrados();
					  
					 include('vista/layout/formulario/header.phtml');
					 include('vista/formulario/index.phtml');
					 include('vista/layout/formulario/footer.phtml');
				
?>