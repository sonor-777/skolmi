<?php 
session_start();

					//include('assignAlert.php');
					
					
					 $valor= new Login();	
					 $vLenguaje=$valor->lenguaje();
					  
					 include('vista/layout/formulario/header.phtml');
					 include('vista/login/login.phtml');
					 include('vista/layout/formulario/footer.phtml');
				
?>