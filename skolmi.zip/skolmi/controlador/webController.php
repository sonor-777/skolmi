<?php 
session_start();

					//include('assignAlert.php');
					include ('./modelo/iwant/ievents/model.DatosPersonales.php'); 
					$valor= new iWant();	
					$ValorBanner=$valor->colsultaBanner($idioma);
					  
					 include('vista/web/layout/index/header.phtml');
					 include('vista/web/index/index.phtml');
					 include('vista/web/layout/index/footer.phtml');
				
?>