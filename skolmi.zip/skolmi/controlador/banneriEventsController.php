<?php 
session_start();

					//include('assignAlert.php');
					
					  include ('./modelo/iwant/ievents/model.DatosPersonales.php'); 
					  $valor= new iWant();	
					  $lenguajes=$valor->colsultarLenguajes();
					  
					 include('vista/layout/inicio/header.phtml');
					 include('vista/inicio/inicio/banneriEvents.phtml');
					 include('vista/layout/inicio/footer.phtml');
				
?>