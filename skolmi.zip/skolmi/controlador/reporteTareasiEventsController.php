<?php 
session_start();

				
					 include('vista/layout/inicio/header.phtml');
					 include('vista/inicio/inicio/reporteTareasiEvents.phtml');
					 include('vista/layout/inicio/footer.phtml');
				
?>