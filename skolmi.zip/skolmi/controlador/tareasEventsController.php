<?php 
session_start();

					//include('assignAlert.php');
					
					//   include ('./modelo/iwant/ievents/model.DatosPersonales.php'); 
					//   $valor= new iWant();	
					//   $seleccionaridiomas=$valor->colsultarIdiomas();
					  
					 include('vista/layout/inicio/header.phtml');
					 include('vista/inicio/inicio/tareasiEvents.phtml');
					 include('vista/layout/inicio/footer.phtml');
				
?>