<?php 
session_start();

require_once('modelo/iwant/ievents/class.Conexion.php');
require_once('modelo/iwant/ievents/modelLogin.php'); 


require_once('core/core.php');
require_once('core/idioma.php');

if(!empty($_POST['iwantevents']) or isset($_POST['iwantevents'])){	
$iwantevents=(isset($_POST['iwantevents']) )? $_POST['iwantevents'] : 'login';
}
elseif(!empty($_SESSION['iwantevents']) or isset($_POST['iwantevents'])){
$iwantevents=(isset($_SESSION['iwantevents']) )? $_SESSION['iwantevents'] : 'login';
}



$_SESSION['iwantevents']=$iwantevents;

if(isset($_SESSION['iwantevents']) or isset($_POST['iwantevents'])){ 
		if(file_exists('controlador/'.$iwantevents.'Controller.php')){
			
			include('controlador/'.$iwantevents.'Controller.php');
		}
		else{
			include('controlador/loginController.php');	
			
		}
}
else{
	
	
include('controlador/loginController.php');	
}
unset($_SESSION['iwantevents']) ;

//unlink('./error_log');
	/*session_start();
	session_destroy();*/
?>

