<?php
  class GenerarPass{
	private $cadena;
	private $longitud;
	private $passw;
	
	public function __construct(){
	$this->cadena='ABCDEFGabcdefg0123456789';
	$this->passw='';	
	}
	public function NuevaPass($long){
   $long_cadena=strlen($this->cadena);
   $this->longitud=$long;
   for($x=1;$x<=$this->longitud;$x++){
	  $aleatorio= mt_rand(0,$long_cadena-1);
	  $this->passw.=substr($this->cadena,$aleatorio,1);
   }
   return $this->passw;
    
	}
	  
  }





?>