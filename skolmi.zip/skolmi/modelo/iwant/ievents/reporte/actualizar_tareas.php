<?php
session_start();
include('../../ievents/class.Conexion.php');
include('../../../../core/idioma.php');
include_once "../../../../core/lenguaje/".$_SESSION['idioma']."_idioma.php";
include ('../../ievents/model.DatosPersonales.php');

$tareaId=$_POST['tareaId'];



if(isset($_POST["tareaId"]))  
{ 
$tareaId=$_POST["tareaId"];
$seleccionar= new iWant();
$datos=$seleccionar->seleccionarTareas($tareaId);

}

$fecha=$_REQUEST['fecha']; 
$realizo=$_REQUEST['realizo']; 
$estado=$_REQUEST['estado']; 
$valorId=$_REQUEST['valorId']; 
$valorConf=$_REQUEST['valorConf']; 
$tarea=$_REQUEST['tarea']; 
if($valorConf=="actualizarTarea"){
    if($fecha!="" and $tarea!="" and $realizo!="" and $estado!="" and $valorId!=""){
        
        $seleccionar= new iWant();
        $datos=$seleccionar->actualizarTareas($fecha,$tarea,$realizo,$estado,$valorId);
    }

}




unlink('error_log');
?>