<?php
session_start();
include('../../ievents/class.Conexion.php');
include('../../../../core/idioma.php');
include_once "../../../../core/lenguaje/".$_SESSION['idioma']."_idioma.php";
include ('../../ievents/modelLogin.php');

$usuario=$_POST['usuario'];
$password=$_POST['password'];
$conectar= new Login();
if($usuario!="" and $password!="" ){
$validar=$conectar->validarLogin($usuario,$password);
}

unlink('error_log');
?>