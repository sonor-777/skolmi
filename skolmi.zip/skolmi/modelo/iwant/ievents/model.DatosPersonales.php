<?php
class iWant{
	
	protected $fecha;
	protected $cedula;
	protected $nombre;
	protected $apellido;
	protected $apellido2;
	protected $fechanacimiento;
	protected $email;
	protected $telefono;
	protected $profesion;
	protected $nombrec;
	protected $emialc;
	protected $telefonoc;
	protected $ciudad;
	protected $sector;

	
	
	   /* public function __construct($cedula,$nombre,$apellido,$fechanacimiento,$email,$telefono,$profesion,$nombrec,$emialc,$telefonoc,$apellido2,$ciudad,$sector){
			$this->fecha=date('Y-m-d');
			$this->cedula=$cedula;
			$this->nombre=ucwords(strtolower($nombre));
			$this->apellido=ucwords(strtolower($apellido));
			$this->apellido2=ucwords(strtolower($apellido2));
			$this->fechanacimiento=$fechanacimiento;
			$this->email=strtolower($email);
			$this->telefono=$telefono;
			$this->profesion=ucwords(strtolower($profesion));
			$this->nombrec=ucwords(strtolower($nombrec));
			$this->emailc=strtolower($emailc);
			$this->telefonoc=$telefonoc;
			$this->ciudad=ucwords(strtolower($ciudad));
			$this->sector=ucwords(strtolower($sector));
			
		}*/

//NUEVA TAREA		
public function nuevaTarea($tarea,$fecha){
	$db=new Conexion();

	$valor=$db->query("SELECT * FROM tareas WHERE tarFecha='$fecha' AND tarNombre='$tarea'");
	$valor=$db->recorrer($valor);
				if($valor['tarFecha']=="$fecha" and $valor['tarNombre']=="$tarea" ){

					$_SESSION['iwantevents']="idiomaiEvents";
							?>
					<script>alert ('<?php echo YAESTAENLABASEDEDATOS; ?>');
					</script>
					<?php
			}
			else{
				$db= new Conexion();
				$sqlingresar=$db->query("INSERT INTO tareas(tarFecha,tarNombre) VALUES ('$fecha','$tarea')");
				if($sqlingresar){
									$_SESSION['iwantevents']="idiomaiEvents";
										?>
									<script>alert ('<?php echo AGREGADOCONEXITO ?>');
									</script>
									<?php					
								}
								else{
									$_SESSION['iwantevents']="idiomaiEvents";
										?>
										<script>alert ('<?php echo ERRORDECONEXION ?>');
										</script>
										<?php
								}
				
					}
	}

	//NUEVA TAREA	
	public function reporteTareas($fecha){
		$db=new Conexion();
		$sql=$db->query("SELECT * FROM tareas WHERE tarFecha='$fecha'");
		while($valor=$db->recorrer($sql)){
			$tareas[]=$valor;
		}
	
		
		return $tareas;
	 }


	 /* VALOR ACTUALIZAR TAREAS JSON */
public function seleccionarTareas($tareaId){
	$db= new Conexion();
	$query=$db->query("SELECT * FROM tareas 
						WHERE tarId=$tareaId");	
			$reporteTareas=$db->recorrer($query);
			echo json_encode($reporteTareas); 
	}

	/* ACTUALIZAR TAREAS */
	public function actualizarTareas($fecha,$tarea,$realizo,$estado,$valorId){
		$db= new Conexion();
		$sqlActualizar=$db->query("UPDATE tareas SET tarNombre='".$tarea."',tarFecha='".$fecha."',tarRealizado='".$realizo."',tarEstado='".$estado."' WHERE tarId=".$valorId."");
		if($sqlActualizar){
			?>
			<script>alert ('<?php echo AGREGADOCONEXITO ?>');</script>
			<?php
			
		}
		
	}


	//REPORTE DE LENGUAJES UTILIZAR EN EL SISTEMA 		
// public function colsultarLenguajesA($valorLenguajes){
// 	$db=new Conexion();
// 	$sqllenguajes=$db->query("SELECT * FROM lenguaje WHERE lenEstado='A'");
// 	$lenguajes="<select name='cmbLenguajesA' id='cmbLenguajesA' class='form-control' style='width: 100%;'><option value=''>".SELECCIONAR."</option>";
// 	while($valor=$db->recorrer($sqllenguajes)){
// 		if($valor['lenLetra']==$valorIdiomas){
// 			$lenguajes.="<option selected='selected' value=".$valor['lenLetra'].">".$valor['lenNombre']."</option>"; 
// 		}
// 		else{
			
// 			$lenguajes.="<option value=".$valor['lenLetra'].">".$valor['lenNombre']."</option>";   
// 		}
		
// 	}
// 	$lenguajes.="</select>";
	
// 	return $lenguajes;

// 	}	
			
}

?>