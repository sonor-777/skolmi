<?php
         class Conexion extends mysqli{
	
	public function __construct(){
		//parent::__construct('localhost','sonor777','GERSON26deoctubre','legendarios');
		parent::__construct('localhost','root','root','ievents');
				$this->query("SET NAMES 'utf8';");
		$this->connect_errno ? die('Error conexion') : $x='Conectado';
		unset($x);
		
	}
	
	public function recorrer($y){
	      return mysqli_fetch_array($y);	
	}
	
	public function recorrernum($z){
	      return mysqli_num_rows($z);	
	}
	
	
}

?>