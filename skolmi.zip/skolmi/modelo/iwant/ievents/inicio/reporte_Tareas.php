<?php
session_start();
include('../../ievents/class.Conexion.php');
include('../../../../core/idioma.php');
include_once "../../../../core/lenguaje/".$_SESSION['idioma']."_idioma.php";
include ('../../ievents/model.DatosPersonales.php');

$fecha=$_POST['fecha'];

$conectar= new iWant();


if($fecha!=""){
    $validar=$conectar->reporteTareas($fecha);
    include('../../../../vista/inicio/reportes/tablaReporteTarea.phtml');
}




unlink('error_log');
?>