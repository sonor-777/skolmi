<?php
session_start();
include('../../ievents/class.Conexion.php');
include('../../../../core/idioma.php');
include_once "../../../../core/lenguaje/".$_SESSION['idioma']."_idioma.php";
include ('../../ievents/model.DatosPersonales.php');
$tarea=$_POST['tarea'];
$fecha=$_POST['fecha'];

$consulta= new iWant();


if($tarea!="" and $fecha!="" ){
$nuevatarea=$consulta->nuevaTarea($tarea,$fecha);
}


 
unlink('error_log');
?>
