<?php
   class Login{
	 
	  protected $nombre;
	  protected $apellido;
	  protected $genero;
	  protected $telefono;
	  protected $user;
	  protected $email;
	  protected $pass;
	  protected $perfil;

	       /* public function __construct($nombre,$apellidol){
				
				$this->nombre=ucwords(strtolower($nombre));
				$this->apellido=ucwords(strtolower($apellido));
				
			}*/
			public function lenguaje (){

				$db= new conexion();
				$lenguaje=$db->query("SELECT * FROM lenguaje WHERE lenEstado='A'");
				while($valor=$db->recorrer($lenguaje)){
					$vLenguaje[]=$valor;

				}
				return $vLenguaje;

			}


			public function validarLogin($usuario,$password){
				$db= new Conexion();
				$password=md5($password);
				$login=$db->query("SELECT usuId,usuNombre,usuApellido,usuGenero,usuFoto,usuTelefono,usuNick,usuEmail,usuPassword,usuPerfil,usuEstado,usuFecha FROM usuarios WHERE usuNick='$usuario' AND usuPassword='$password'");
				$dato=$db->recorrer($login);
						if($dato['usuNick']===$usuario and $dato['usuPassword']===$password){
							
							$_SESSION['id']=$dato['usuId'];
							$_SESSION['nombres']=$dato['usuNombre'];
							$_SESSION['apellidos']=$dato['usuApellido'];
							$_SESSION['genero']=$dato['usuGenero'];
							$_SESSION['foto']=$dato['usuFoto'];
							$_SESSION['direccion']=$dato['usuDireccion'];
							$_SESSION['telefono']=$dato['usuTelefono'];
							$_SESSION['usuario']=$dato['usuNick'];
							$_SESSION['email']=$dato['usuEmail'];
							$_SESSION['password']=$dato['usuPassword'];
							$_SESSION['perfil']=$dato['usuPerfil'];
							$_SESSION['estado']=$dato['usuEstado'];
							$_SESSION['fecha']=$dato['usuFecha'];
							
							$nombresmenu=$_SESSION['nombres'];
							$apellidosmenu=$_SESSION['apellidos'];
							$patron_session= "/\s+/";
							$nom_session=preg_split($patron_session,$nombresmenu);
							$ape_session=preg_split($patron_session,$apellidosmenu);
							$_SESSION['nombremenu']=$nom_session[0];
							$_SESSION['apellidomenu']=$ape_session[0];

							$_SESSION['iwantevents']="inicio";
							$_POST['iwantevents']="inicio";
							?><script>alert ('<?php echo BIENVENIDO; ?>');
												 window.location="./";</script>
							 <?php
							
						}
						
					  else{ 
						 $_SESSION['iwantevents']="login";
						 ?><script>alert ('<?php echo ERRORDEUSUARIOOCONTRASENA; ?>');
												 window.location="./";</script>
						 <?php
						 /*$idioma=$_SESSION['idioma']; 
						 $controlador='login';
						 $alertas=new Alertas($idioma,$controlador,4042);
						 $alertas->enviarAlertas();*/
						
						 // echo "enviar('en','login',4042);";
							//header('location: index.php?idioma='.$_SESSION['idioma'].'&sion=login&msn=4042');
					  }
					}
			  
			
	   
   }
   

?>