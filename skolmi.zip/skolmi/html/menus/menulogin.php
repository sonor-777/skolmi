<div class="col-12">
            <!-- Custom Tabs -->
            <div class="card">
              <div class="card-header d-flex p-0">
				<div class="logo">
				</div>
                <ul class="nav nav-pills ml-auto p-2">
                <li class="nav-item"><a onclick="enviar('<?php echo $idioma?>','web')" class="nav-link" href="#"><?php echo INICIO ?></a></li>
                <li class="nav-item">
                      <div class="input-group">
                        <div class="input-group-append">
                          <div class="dropdown-menu">
                          <?php 
                          foreach ($vLenguaje as $rLenguaje){
                            $letraL=$rLenguaje['lenLetra'];
                            $nombreL=$rLenguaje['lenNombre'];
                             echo "<a onclick=enviar('$letraL','login') class='dropdown-item' href='#'>$nombreL</a>";
                          } 
                          ?>
                         
                            <!--<div role="separator" class="dropdown-divider"></div> -->
                          </div>
                        </div>
                      </div>
                </li>
                <li></li>
                </ul>
              </div><!-- /.card-header -->
            </div>
            <!-- ./card -->
           </div>
          <!-- /.col -->